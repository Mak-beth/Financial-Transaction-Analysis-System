#ifndef PERFORMANCE_METRICS_HPP
#define PERFORMANCE_METRICS_HPP

#include <string>

void showPerformanceMetrics(const std::string& operation, long long timeMs, double memoryMB, size_t spaceUsed);

#endif
